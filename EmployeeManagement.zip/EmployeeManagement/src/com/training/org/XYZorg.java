package com.training.org;

import java.util.ArrayList;
import java.util.Scanner;

public class XYZorg {

	public static void main(String[] args) {
//		Employee e1 =new Employee();
//		System.out.println(e1);
//		
//		Employee e2 =new Employee(101,"Eshan",10000);
//		System.out.println(e2);
		
		ArrayList<Employee> empList = new ArrayList<Employee>();
		Scanner input = new Scanner(System.in);
		char ch;
		int flag=0;
		int flag1=0;
		do {
			System.out.println("1]Add new Record\n2] Display records\n3]Delete record\n4] Update Record\n\n");
			int choice=input.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter empId");
				int id=input.nextInt();
				System.out.println("Enter name");
				String name =input.next();
				System.out.println("Enter salary");
				double sal =input.nextDouble();
				
				empList.add(new Employee(id,name,sal));
				System.out.println("Record is added successfully");
				break;

			case 2:
				System.out.println("**********Employee records are************");
				for (Employee emp : empList) {
					System.out.println(emp);
				}
				
				break;
				
			case 3:
				System.out.println("Enter the name to delete");
				String nm =input.next();
				
				for(int i=0;i<empList.size();i++) {
					if(empList.get(i).getEmpName().equals(nm)) {
						empList.remove(i);
						System.out.println("Record is deleted successfully");
						flag=1;
						break;
					}
					
				}
				
				if (flag==0) {
					System.out.println("Record is not available");
				}
				
				break;
				
			case 4:
				System.out.println("4.1] Upodate name\n4.2]Update salary\n\n");
				int choice1=input.nextInt();
				switch (choice1) {
				case 1:
					System.out.println("Enter the old name to replace");
					String mOld= input.next();
					for (int i = 0; i < empList.size(); i++) {
						if(empList.get(i).getEmpName().equals(mOld)) {
							System.out.println("Enter the new name to replace with"+mOld+"name");
							String newName=input.next();
							empList.get(i).setEmpName(newName);
							System.out.println("Updated the name succesfully...");
							flag1=1;
							break;
						}
						
					}
					if (flag1==0) {
						System.out.println("Record not found for updation");
					}
						
					
					break;
					
				case 2:
					System.out.println("Provide yearly increment for employee with condition");
					System.out.println("Enter the salary with condition...");
					int checkSal=input.nextInt();
					
					System.out.println("Enter the increment percentage");
					double incrementPer=input.nextDouble();
					
					for (int i = 0; i < empList.size(); i++) {
						if(empList.get(i).getSalary()<checkSal) {
							empList.get(i).setSalary(empList.get(i).getSalary()*(incrementPer/100+1));
						}
						
					}

				default:
					break;
				}
				
			default:
		
				
				System.out.println("Invalid choice......");
				break;
			}
			System.out.println("Do you want to continue.....");
			ch=input.next().charAt(0);
		}
		while(ch=='y'||ch=='Y');
		System.out.println("I m done");
	}
}
