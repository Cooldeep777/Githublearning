package com.training.org;

public class Complex {
   private int real;
   private int imag;
   
   
   
   public Complex() {
    System.out.println("Default Constructor of Complex is called");
     real =0;
      imag=0;
}
   
   
   public void showComplexValues() {
	   System.out.println("Complex values "+real+"and"+img);
   }
//@Override
//public String toString() {
//	return "Complex [real=" + real + ", imag=" + imag + "]";
//}
//public Complex(int real, int imag) {
//	super();
//	this.real = real;
//	this.imag = imag;
//}
//public int getReal() {
//	return real;
//}
//public void setReal(int real) {
//	this.real = real;
//}
//public int getImag() {
//	return imag;
//}
//public void setImag(int imag) {
//	this.imag = imag;
//}
    public static void main(String[] args) {
		Complex c1=new Complex();
		System.out.println(c1);
	}
   
}
